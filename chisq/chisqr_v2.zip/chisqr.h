

#ifndef H__CHISQR
#define H__CHISQR


extern double chisqr(int Dof, double Cv);

#endif


